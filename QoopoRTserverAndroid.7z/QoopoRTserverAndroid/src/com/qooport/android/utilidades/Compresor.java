package com.qooport.android.utilidades;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
public class Compresor {
    public static byte[] comprimirGZIP(byte[] file) throws IOException {
        ByteArrayOutputStream gzdata = new ByteArrayOutputStream();
        GZIPOutputStream gzipper = new GZIPOutputStream(gzdata);
        ByteArrayInputStream data = new ByteArrayInputStream(file);
        byte[] readed = new byte[1024];
        int actual = 1;
        while ((actual = data.read(readed)) > 0) {
            gzipper.write(readed, 0, actual);
        }
        gzipper.finish();
        data.close();
        byte[] compressed = gzdata.toByteArray();
        gzdata.close();
        return compressed;
    }
    public static byte[] descomprimirGZIP(byte[] file) throws IOException {
        ByteArrayInputStream gzdata = new ByteArrayInputStream(file);
        GZIPInputStream gunzipper = new GZIPInputStream(gzdata, file.length);
        ByteArrayOutputStream data = new ByteArrayOutputStream();
        byte[] readed = new byte[1024];
        int actual = 1;
        while ((actual = gunzipper.read(readed)) > 0) {
            data.write(readed, 0, actual);
        }
        gzdata.close();
        gunzipper.close();
        byte[] returndata = data.toByteArray();
//        csvdata.close();
        return returndata;
    }
}
