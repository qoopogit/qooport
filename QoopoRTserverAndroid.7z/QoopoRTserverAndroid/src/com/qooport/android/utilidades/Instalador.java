package com.qooport.android.utilidades;
import java.io.File;
public class Instalador {
    private String nombreJar;
    private String nombreReg;
    private boolean[] tipo = new boolean[2];
    private File destino;
    public Instalador(String nombreJar, String nombreReg, boolean tipo1, boolean tipo2) {
        this.nombreJar = nombreJar;
        this.nombreReg = nombreReg;
        this.tipo[0] = tipo1;
        this.tipo[1] = tipo2;
    }
    public void instalar() {
        String so = System.getProperty("os.name").toLowerCase();
        if (so.contains("win")) {
//            instalarWindows();
        } else if (so.contains("linux")) {
//            instalarLinux();
        } else if (so.contains("mac")) {
//            instalarMac();
        }
    }
    public void inicia() {
        instalar();
    }
}
