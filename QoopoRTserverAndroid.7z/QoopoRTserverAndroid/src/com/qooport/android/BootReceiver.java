package com.qooport.android;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class BootReceiver extends BroadcastReceiver {

    public final String TAG = BootReceiver.class.getSimpleName();

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.i(TAG, "SE RECIBIO EL LANZADOR DE BOOTEO");
        String action = intent.getAction();
        if (action.equals(Intent.ACTION_BOOT_COMPLETED)) { //android.intent.action.BOOT_COMPLETED
            Log.i(TAG, "VOY A LEVANTAR A LA ACTIVIDAD");
            Intent serviceIntent = new Intent(context, Principal.class);
            serviceIntent.setAction(BootReceiver.class.getSimpleName());
            serviceIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            context.startService(serviceIntent);
            context.startActivity(serviceIntent);
        }
    }
}
